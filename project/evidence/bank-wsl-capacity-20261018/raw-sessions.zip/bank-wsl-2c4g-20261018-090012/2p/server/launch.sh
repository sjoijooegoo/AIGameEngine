#!/bin/sh
echo $$ > /mnt/d/AIGameEngine/logs/performance/bank-wsl-2c4g-20261018-090012/2p/server/pid
exec /home/song/.local/share/aigameengine-bank/benchmark/godot-debug --headless --path /mnt/d/AIGameEngine/game/runtime --script /mnt/d/AIGameEngine/game/tests/wsl_coop_performance.gd -- --test-session=/mnt/d/AIGameEngine/logs/performance/bank-wsl-2c4g-20261018-090012/2p/server --performance-benchmark --coop --server --port=24882 --max-players=2
