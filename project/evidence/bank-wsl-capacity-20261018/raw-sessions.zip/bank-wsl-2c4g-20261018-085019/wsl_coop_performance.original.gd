extends "coop_combat_performance.gd"
## Extra wall-clock tick spacing for the resource-limited Linux benchmark.
## Inherits the existing bounded debug-only input and fixture protocol.
func _physics_process(dt: float) -> bool:
	var started := Time.get_ticks_usec()
	var result := super._physics_process(dt)
	if measuring and not game.world.profiler.ticks.is_empty():
		game.world.profiler.ticks[-1].started_usec = started
	return result
