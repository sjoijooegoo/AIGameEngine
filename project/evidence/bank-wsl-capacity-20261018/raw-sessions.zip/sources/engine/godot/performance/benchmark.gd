extends SceneTree
## A real-time runner, separate from the frozen test bridge. Project subclasses
## own fixtures and input routes. No --fixed-fps, capture, or disk writes in samples.
var plan: Dictionary
var case_index := -1
var case_tick := 0
var running := false
var rows: Array = []
var output := ""

func _initialize() -> void:
	if not OS.is_debug_build():quit(1);return
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--performance-plan="):
			plan=JSON.parse_string(FileAccess.get_file_as_string(arg.trim_prefix("--performance-plan=")))
	if plan.is_empty():quit(2);return
	output=plan.output
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
	Engine.max_fps=0
	call_deferred("boot")

func boot() -> void:
	change_scene_to_file(plan.scene)
	await process_frame
	await process_frame
	await prepare_project()
	next_case()

func prepare_project() -> void:pass
func setup_case(_case: Dictionary) -> void:pass
func drive_tick(_tick: int, _case: Dictionary) -> void:pass
func advance_project(_dt: float) -> void:pass
func observe_case() -> Dictionary:return {}
func monitor() -> Node:return null

func next_case() -> void:
	case_index+=1
	if case_index>=plan.cases.size():
		var file:=FileAccess.open(output.path_join("raw.json"),FileAccess.WRITE)
		file.store_string(JSON.stringify({"schema_version":1,"plan":plan,"cases":rows}));quit();return
	setup_case(plan.cases[case_index]);case_tick=0;running=true

func _physics_process(dt: float) -> bool:
	if not running:return false
	var config: Dictionary=plan.cases[case_index]
	if case_tick==int(config.warmup_ticks):monitor().start_recording()
	drive_tick(case_tick,config)
	advance_project(dt)
	case_tick+=1
	if case_tick>=int(config.warmup_ticks)+int(config.measure_ticks):
		running=false;call_deferred("finish_case")
	return false

func finish_case() -> void:
	var data: Dictionary=monitor().stop_recording()
	data.case=plan.cases[case_index];data.outcome=observe_case()
	rows.append(data)
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png(output.path_join("%02d-%s.png" % [case_index,data.case.id]))
	print("PERFORMANCE_CASE ",data.case.id," frames=",data.frames.size()," ticks=",data.ticks.size())
	call_deferred("next_case")
