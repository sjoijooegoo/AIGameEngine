#!/bin/sh
echo $$ > /mnt/d/AIGameEngine/logs/performance/bank-wsl-2c4g-20261018-091550/4p/server/pid
exec /home/song/.local/share/aigameengine-bank/benchmark/godot-debug --headless --path /mnt/d/AIGameEngine/game/runtime --script /mnt/d/AIGameEngine/game/tests/wsl_coop_hold.gd -- --test-session=/mnt/d/AIGameEngine/logs/performance/bank-wsl-2c4g-20261018-091550/4p/server --performance-benchmark --coop --server --port=24884 --max-players=4
