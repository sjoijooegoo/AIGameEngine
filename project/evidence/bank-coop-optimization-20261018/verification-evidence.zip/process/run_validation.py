import subprocess,sys,time
from pathlib import Path
root=Path(__file__).resolve().parents[2]
commands=[
 ('network-combat',['game.tests.verify_network_combat','--project','bank']),
 ('network-recovery',['game.tests.verify_network_recovery','--project','bank']),
 ('network-matrix',['game.tests.verify_network_resilience','--project','bank','--repeat','2','--profiles','rtt100','rtt300','rtt500_loss5','rtt800_loss10','rtt200_loss20','reorder_duplicate','--sample-seconds','10']),
 ('visual',['game.tests.verify_network_visuals','--project','bank'])]
for name,args in commands:
 print('START',name,flush=True)
 with (root/'logs/coop-optimization'/(name+'.log')).open('w',encoding='utf8') as log:
  result=subprocess.run([sys.executable,'-m',*args],cwd=root,stdout=log,stderr=subprocess.STDOUT)
 print('FINISH',name,'exit',result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
