#!/bin/sh
echo $$
exec /mnt/d/AIGameEngine/build/bank/coop/20261017-110530-174952/package/bank-coop-server.x86_64 --headless -- --server --port=24780
