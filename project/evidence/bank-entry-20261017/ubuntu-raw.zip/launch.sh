#!/bin/sh
echo $$
exec /mnt/d/AIGameEngine/build/bank/combat-coop/20261017-143654/linux/package/bank-coop-server.x86_64 --headless -- --server --port=24751 --max-players=4
